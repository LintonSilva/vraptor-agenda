# VRaptor blank project

This is a blank project to help you to use VRaptor. You can easily import in you IDE as Maven project.

Este é um projeto em branco para ajudar você a usar o VRaptor. Você pode facilmente importá-lo na sua IDE favorita como um projeto Maven.
